import UIKit

var ilce: String = "Meram"
var kita: String = "Avrupa"
var faks: String = "34343435443"
var postaKodu: String = "43857489"
var instaAdres: String = "@sudecoding"
var calistiginBolum: Int = 300
var odemeMiktari: Double = 130.74
var dogumTarihi: String = "19/08/2000"
var borc: Double = 700.50
var medeniHal: String = "Bekar"
var videoYorumu: String = "Videoya bayıldım!"
var sirket: String = "Apple Inc."
var videoAdi: String = "Swift ile Mobil Uygulama Geliştirme"
var muzikSuresi: Double = 3.45
var mekanPuani: Double = 4.8
var dosyaAdi: String = "swift.pdf"
var resimFormati: String = "JPEG"
var renk: String = "Mavi"
var renkKodu: String = "#030ADF"
var bilgisayarModeli: String = "MacBook Pro"
var ekranBoyutu: Double = 16.0
var kullanimSuresi: Int = 24
